var fs = require('fs');
var os = require('os');


/* Begin ---- Tenant auth info */

var tenancyId=  "ocid1.tenancy.oc1..aaaaaaaawrgt5au6hbledhhyas2secm3q2atqiuvihck45rbi3jyc5tfyfga";
var authUserId= "ocid1.user.oc1..aaaaaaaavscszlxxcf2wnq73nxpguxtubvpxaklqbspmuuml7xxp26mbxmgq";
var keyFingerprint = "0d:33:d8:eb:9a:48:2a:15:cd:36:2e:f5:20:fe:b3:d3";
var Compartment = "ocid1.compartment.oc1..aaaaaaaai75jrzzbfe6t43fd6yivpqngk2tufisqnohacf3s26p6uhcgz7bq";
var privateKeyPath = "/home/oracle/labs/rest/oci_api_key.pem";

if(privateKeyPath.indexOf("~/") === 0) {
    privateKeyPath = privateKeyPath.replace("~", os.homedir())
}
var privateKey = fs.readFileSync(privateKeyPath, 'ascii');

/* End ---- Tenant auth info */

module.exports = {
tenancyId: tenancyId,
authUserId: authUserId,
keyFingerprint: keyFingerprint,
privateKey: privateKey,
Compartment: Compartment

};


